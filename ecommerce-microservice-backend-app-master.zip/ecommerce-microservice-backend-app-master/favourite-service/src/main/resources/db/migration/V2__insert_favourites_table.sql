
INSERT INTO favourites
(user_id, product_id) VALUES
(1, 1),
(1, 2),
(2, 2);

