
INSERT INTO address
(user_id, full_address, postal_code, city) VALUES
(1, 'carthage byrsa', '2016', 'carthage'),
(2, 'carthage byrsa', '2016', 'carthage'),
(3, 'carthage byrsa', '2016', 'carthage'),
(4, 'carthage byrsa', '2016', 'carthage'),
(2, 'kram', '2015', 'kram'),
(1, 'kram', '2015', 'kram');


