
INSERT INTO credentials
(user_id, username, password, role, is_enabled) VALUES
(1, 'selimhorri', '$2a$04$/S7cWjHPZul03sPEivycWeKTBvLyjYdaRWmeaFbiqKy9es/3W4QB6', 'ROLE_USER', true),
(2, 'amineladjimi', '$2a$04$8D8OuqPbE4LhRckvtBAHrOmpeWmE92xNNVtyK8Z/lrJFjsImpjBkm', 'ROLE_USER', true),
(3, 'omarderouiche', '$2a$04$jelNGcF4wFHJirT5Pm7jPO8812QE/3tIWIs1DNnajS68iG4aKUqvS', 'ROLE_USER', true),
(4, 'admin', '$2a$04$1G4TwSzwf5JwZ4dKCXG1Zu1Qh3WIY9JNaM9vF6Ff05QDfyPg7nSxO', 'ROLE_USER', true);

