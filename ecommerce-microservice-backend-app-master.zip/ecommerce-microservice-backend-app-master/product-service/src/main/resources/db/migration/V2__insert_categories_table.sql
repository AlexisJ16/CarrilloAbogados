
INSERT INTO categories
(parent_category_id, category_title) VALUES
(null, 'Computer'),
(null, 'Mode'),
(null, 'Game');

