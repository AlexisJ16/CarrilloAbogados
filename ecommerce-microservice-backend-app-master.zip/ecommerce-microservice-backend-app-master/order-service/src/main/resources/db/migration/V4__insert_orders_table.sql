
INSERT INTO orders
(cart_id, order_desc, order_fee) VALUES
(1, 'init', 5000),
(2, 'init', 5000),
(3, 'init', 5000),
(4, 'init', 5000);

