
INSERT INTO carts
(user_id) VALUES
(1),
(2),
(3),
(4);

